const socket = io();
const $ = (id) => document.getElementById(id);

const nameEl = $("name");
const roomEl = $("room");
const logEl = $("log");
const handEl = $("hand");
const tableInfo = $("tableInfo");
const tableCards = $("tableCards");
const playerList = $("playerList");
const roomDisplay = $("roomDisplay");
const roomBadge = $("roomBadge");
const lobbyView = $("lobbyView");
const cardCountEl = $("cardCount");

const btnCreate = $("btnCreate");
const btnJoin = $("btnJoin");
const btnStart = $("btnStart");
const btnNewRound = $("btnNewRound");
const btnSam = $("btnSam");
const btnNoSam = $("btnNoSam");
const btnPass = $("btnPass");
const btnPlay = $("btnPlay");
const btnSort = $("btnSort");

const RANK_ORDER = ["3","4","5","6","7","8","9","10","J","Q","K","A","2"];

function getCardUI(cardId) {
  const r = cardId.slice(0, -1);
  const s = cardId.slice(-1);
  const isRed = s === "♦" || s === "♥";
  const div = document.createElement("div");
  div.className = `cardUI ${isRed ? "red" : "black"}`;
  div.innerHTML = `<div class="r">${r}</div><div class="s">${s}</div>`;
  return div;
}

let myHand = [];
let selected = new Set();
let lastState = null;

function log(msg) {
  const line = document.createElement("div");
  line.className = "logLine";
  line.textContent = msg;
  logEl.appendChild(line);
  logEl.scrollTop = logEl.scrollHeight;
}

function renderHand() {
  handEl.innerHTML = "";
  // Không reset 'selected' ở đây nữa để giữ trạng thái chọn lá
  cardCountEl.textContent = `${myHand.length} lá`;

  for (const c of myHand) {
    const div = getCardUI(c.id);
    if (selected.has(c.id)) {
      div.classList.add("selected");
    }
    div.onclick = () => {
      if (selected.has(c.id)) {
        selected.delete(c.id);
        div.classList.remove("selected");
      } else {
        selected.add(c.id);
        div.classList.add("selected");
      }
    };
    handEl.appendChild(div);
  }
}

function renderScoreboard(state) {
  if (!state) return;
  playerList.innerHTML = "";
  
  const myId = socket.id;
  const isHost = myId === state.hostId;
  const phase = state.phase;

  // Update Room Display
  roomDisplay.textContent = state.id;
  roomBadge.style.display = "block";
  lobbyView.style.display = "none";

  // Control Buttons
  btnStart.style.display = (isHost && phase === "LOBBY") ? "block" : "none";
  btnNewRound.style.display = (isHost && phase === "ROUND_END") ? "block" : "none";
  
  const isMyTurn = myId === state.turnId;
  btnPass.style.display = (phase === "PLAYING" && isMyTurn) ? "block" : "none";
  btnPlay.style.display = (phase === "PLAYING" && isMyTurn) ? "block" : "none";
  
  // Sam buttons
  const hasDeclared = state.declare?.done?.[myId];
  btnSam.style.display = (phase === "DECLARE_SAM" && !hasDeclared) ? "block" : "none";
  btnNoSam.style.display = (phase === "DECLARE_SAM" && !hasDeclared) ? "block" : "none";

  for (const p of state.players) {
    const div = document.createElement("div");
    div.className = "player";
    
    const isPTurn = p.id === state.turnId;
    const isPHost = p.id === state.hostId;
    const isPSam = state.sam?.active && p.id === state.sam.declaredBy;
    const isBao1 = p.cardCount === 1;
    
    div.innerHTML = `
      <div class="left">
        <b>${p.name}</b>
        ${isPHost ? '<span class="badge host">HOST</span>' : ''}
        ${isPSam ? '<span class="badge" style="border-color:#ff3b3b; color:#ff3b3b">SÂM</span>' : ''}
        ${isBao1 ? '<span class="badge" style="border-color:#f39c12; color:#f39c12; font-weight:bold">BÁO 1</span>' : ''}
        ${isPTurn ? '<span class="badge turn">LƯỢT</span>' : ''}
      </div>
      <div class="muted">${state.points[p.id] || 0} pts</div>
    `;
    playerList.appendChild(div);
  }
}

function renderTable(state) {
  if (!state) return;
  const t = state.table || {};
  const cards = t.cards || [];
  
  tableCards.innerHTML = "";
  if (!cards.length) {
    tableInfo.textContent = state.phase === "PLAYING" ? "Bàn trống - Mời đánh" : "Đang chờ...";
  } else {
    tableInfo.textContent = `${t.holderName} vừa đánh ${t.type}`;
    for (const c of cards) {
      tableCards.appendChild(getCardUI(c));
    }
  }
}

socket.on("connect", () => log("✅ Đã kết nối"));
socket.on("disconnect", () => log("❌ Mất kết nối"));
socket.on("log", (m) => log(m));
socket.on("error_msg", (m) => log("⚠️ " + m));

socket.on("hand", (cards) => {
  myHand = Array.isArray(cards) ? cards : [];
  
  // Dọn dẹp những card đã mất khỏi 'selected'
  const currentIds = new Set(myHand.map(c => c.id));
  for (const id of selected) {
    if (!currentIds.has(id)) {
      selected.delete(id);
    }
  }

  renderHand();
});

socket.on("room_update", (state) => {
  lastState = state;
  renderScoreboard(state);
  renderTable(state);
});

btnCreate.onclick = () => {
  const name = (nameEl.value || "").trim();
  if (!name) return alert("Nhập tên");
  socket.emit("create_room", { name });
};

btnJoin.onclick = () => {
  const name = (nameEl.value || "").trim();
  const roomId = (roomEl.value || "").trim();
  if (!name || !roomId) return alert("Nhập tên + mã phòng");
  socket.emit("join_room", { name, roomId });
};

btnStart.onclick = () => socket.emit("start_game");
btnNewRound.onclick = () => socket.emit("new_round");
btnSam.onclick = () => socket.emit("declare_sam", { flag: true });
btnNoSam.onclick = () => socket.emit("declare_sam", { flag: false });
btnPass.onclick = () => socket.emit("pass");
btnPlay.onclick = () => {
  const cardIds = [...selected];
  if (cardIds.length === 0) return alert("Chọn lá trước");
  socket.emit("play_cards", { cardIds });
  // Sau khi đánh bài thành công (hoặc gửi lệnh), ta sẽ đợi server gửi lại 'hand' mới để cập nhật selected
};

btnSort.onclick = () => {
  myHand.sort((a, b) => {
    const ra = RANK_ORDER.indexOf(a.r);
    const rb = RANK_ORDER.indexOf(b.r);
    if (ra !== rb) return ra - rb;
    const SUITS = ["♠","♣","♦","♥"];
    return SUITS.indexOf(a.s) - SUITS.indexOf(b.s);
  });
  renderHand();
};
